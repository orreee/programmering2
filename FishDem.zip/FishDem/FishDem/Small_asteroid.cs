﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharpDX.Direct3D9;

namespace FishDem
{
    public class Small_asteroid
    {
        public Texture2D tex;
        public Vector2 pos;
        public Vector2 velocity_x;
        public Vector2 velocity_y;
        public int width;
        public int height;
        public Rectangle rectangle;
        public int speedx;
        public int speedy;


        public Small_asteroid(Texture2D tex, Vector2 pos, Vector2 velocity_x, Vector2 velocity_y, int width, int height, Rectangle rectangle, int speedx, int speedy)
        {
            this.tex = tex;
            this.pos = pos;
            this.velocity_x = velocity_x;
            this.velocity_y = velocity_y;
            this.width = width;
            this.height = height;
            this.rectangle = rectangle;
            this.speedx = speedx;
            this.speedy = speedy;
        }
        public void Update()
        {
            rectangle.X = rectangle.X + speedx;
            pos = pos + velocity_x;
            if (pos.X < 0 || pos.X > width - tex.Width)
            {
                velocity_x = velocity_x * -1;
                speedx = speedx * -1;
            }
            rectangle.Y = rectangle.Y + speedy;
            pos = pos + velocity_y;
            if (pos.Y < 0 || pos.Y > height - tex.Height)
            {
                velocity_y = velocity_y * -1;
                speedy = speedy * -1;
            }

            /*GetState(MouseState)
            MouseState mouseState = new MouseState(pos.X,pos.Y,0,ButtonState.Pressed, ButtonState.Released, ButtonState.Released, ButtonState.Released, ButtonState.Released);
            
            rectangle.Contains()
            
            if (mouseState.Equals(rectangle))
            {

            }
            */
        }
        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(tex, pos, Color.White);
        }
    }
}
