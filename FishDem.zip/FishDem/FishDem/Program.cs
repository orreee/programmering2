﻿using var game = new FishDem.Game1();
game.Run();
