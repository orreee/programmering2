﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace FishDem
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager graphics;
        public SpriteBatch spriteBatch;
        public Texture2D small_asteroid_sprite;
        public Vector2 pos;
        public int width;
        public int height;
        public Vector2 velocity_x;
        public Vector2 velocity_y;
        public Small_asteroid small_asteroid;
        Small_asteroid[] asteroid_array = new Small_asteroid[3];
        List<Small_asteroid> small_asteroids = new List<Small_asteroid>();

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
        }

        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            pos = new Vector2(700, 0);

            // TODO: use this.Content to load your game content here

            small_asteroid_sprite = Content.Load<Texture2D>("asteroid_small");
            //bool hit = small_asteroid_sprite.Bounds.Contains(x, y)
            for (int i = 0; i < asteroid_array.Length; i++)
            {
                var Random = new Random();
                int x_axis;
                int random_index;
                random_index = Random.Next(1, 4);
                int speed1 = random_index;
                random_index = Random.Next(1, 4);
                int speed2 = random_index;
                random_index = Random.Next(0, 2);
                if (random_index == 1)
                {
                    x_axis = 700;
                }
                else { x_axis = 0; }

                random_index = Random.Next(0, 370);
                width = Window.ClientBounds.Width;
                height = Window.ClientBounds.Height;
                velocity_x = new Vector2(2, 0);
                velocity_y = new Vector2(0, 2);
                // asteroid objekt
                Vector2 pos2 = new Vector2(x_axis, random_index);
                Vector2 velocity2x = new Vector2(speed1, 0);
                Vector2 velocity2y = new Vector2(0, speed2);
                Rectangle rectangle = new Rectangle(x_axis, random_index, small_asteroid_sprite.Width, small_asteroid_sprite.Height);
                small_asteroid = new Small_asteroid(small_asteroid_sprite, pos2, velocity2x, velocity2y, width, height, rectangle, speed1, speed2);
                /*asteroid_array[i] = small_asteroid;*/
                small_asteroids.Add(small_asteroid);
            }

        }

        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // TODO: Add your update logic here



            pos = pos + velocity_x;
            if (pos.X < 0 || pos.X > width - small_asteroid_sprite.Width)
            {
                velocity_x = velocity_x * -1;
            }
            for (int i = 0; i < small_asteroids.Count; i++)
            {
                /*asteroid_array[i].Update();*/
                small_asteroids[i].Update();
            }



            var mouseState_pos = Mouse.GetState();
            var mouseState_pressed = Mouse.GetState().LeftButton;
            for (int i = 0; i < small_asteroids.Count; i++)
            {
                //*
                for (int j = 0; j < small_asteroids.Count; j++)
                {
                    if (small_asteroids[i].rectangle.Contains(small_asteroids[j].pos))
                    {
                        small_asteroids[i].velocity_x = small_asteroids[i].velocity_x * -1;
                        small_asteroids[i].speedx = small_asteroids[i].speedx * -1;
                        small_asteroids[i].velocity_y = small_asteroids[i].velocity_y * -1;
                        small_asteroids[i].speedy = small_asteroids[i].speedy * -1;

                        small_asteroids[j].velocity_x = small_asteroids[j].velocity_x * -1;
                        small_asteroids[j].speedx = small_asteroids[j].speedx * -1;
                        small_asteroids[j].velocity_y = small_asteroids[j].velocity_y * -1;
                        small_asteroids[j].speedy = small_asteroids[j].speedy * -1;
                    }
                }
                //*/
                if (small_asteroids[i].rectangle.Contains(mouseState_pos.X, mouseState_pos.Y) && mouseState_pressed == ButtonState.Pressed)
                {

                    small_asteroids.Remove(small_asteroids[i]);
                }
            }

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);

            // TODO: Add your drawing code here
            spriteBatch.Begin();
            /* spriteBatch.Draw(small_asteroid_sprite, pos, Color.White);*/
            for (int i = 0; i < small_asteroids.Count; i++)
            {
                small_asteroids[i].Draw(spriteBatch);
            }
            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}